# STATS205_FinalProject_Bitcoin

This repo contains the code for Non-parametric approach to Bitcoin Return Prediction

by Sameer Sundrani (sundrani), Luis Alcaraz (alcaraz), and Raphael Brosula (brosular)

Files available:

Non-ParametricMethods.ipynb (Google Colab notebook with all LSTM, Local Averaging, and Linear Interpolation Models)
BTC_Nonparametric.ipynb (Google Colab notebook with all ANN, Spline, and Data processing)

Contact sundrani@stanford.edu with any questions!
